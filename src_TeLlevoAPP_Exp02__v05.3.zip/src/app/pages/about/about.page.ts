import { Component, OnInit } from '@angular/core';
import { MenuController } from '@ionic/angular';
import { AlertController, NavController } from '@ionic/angular';
@Component({
  selector: 'app-about',
  templateUrl: './about.page.html',
  styleUrls: ['./about.page.scss'],
})
export class AboutPage implements OnInit {

  constructor(
    public alertController: AlertController,
    public navCtrl: NavController,) { }

  ngOnInit() {
  }
/* ----------------- SALIR  / LogOut ------------------------------- */
async salir(){
  const alert = await this.alertController.create({
    header: 'Salir',
    message: '¿Quieres Salir?',
    buttons: [
      {
        text: 'No',
        handler: () => {
          
        }
      }, {
        text: 'Si',
        handler: () => {
          localStorage.removeItem('ingresado');
          this.navCtrl.navigateRoot('login');
        }
      }
    ]
  });

  await alert.present();
}
/* ----------------- SALIR  / LogOut ------------------------------- */
}
