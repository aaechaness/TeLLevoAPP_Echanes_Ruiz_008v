import { Component, OnInit } from '@angular/core';
import { AlertController } from '@ionic/angular';
import { RegistroserviceService, Usuario } from '../../services/registroservice.service';
import { ToastController } from '@ionic/angular';
import { NavController } from '@ionic/angular';
import {
  FormGroup,
  FormControl,
  Validators,
  FormBuilder
} from '@angular/forms';


@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
})
export class RegisterPage implements OnInit {

  formularioRegistro: FormGroup;
  newUsuario: Usuario = <Usuario>{};

  constructor(private alertController: AlertController,
              private navController: NavController, 
              private registroService: RegistroserviceService,
              private toastController: ToastController,
              private fb:FormBuilder) { 
                this.formularioRegistro = fb.group({
                    'tipo' : new FormControl("", Validators.required),
                    'nombre' : new FormControl("", Validators.required),
                    'correo' : new FormControl("", Validators.required),  
                    'password': new FormControl("", Validators.required),
                    'confirmaPass': new FormControl("", Validators.required),
                    'carrera': new FormControl("", Validators.required),
                    'sede': new FormControl("", Validators.required),
                    'modelo': new FormControl,
                    'patente': new FormControl
                 })
              }

  ngOnInit() {
  }

  async CrearUsuario(){
    var form= this.formularioRegistro.value;
    if (this.formularioRegistro.invalid){
      const alert = await this.alertController.create({ 
        header: 'Datos incompletos',
        message: 'Debe completar todos los datos',
        buttons: ['Aceptar']
      });
      await alert.present();
      return;
    }
    this.newUsuario.tipRegistro = form.tipo;
    this.newUsuario.nomUsuario = form.nombre;
    this.newUsuario.correoUsuario = form.correo;
    this.newUsuario.passUsuario = form.password;
    this.newUsuario.repassUsuario = form.confirmaPass;
    this.newUsuario.carrera = form.carrera;
    this.newUsuario.sede = form.sede;
    this.newUsuario.autoModelo = form.modelo;
    this.newUsuario.autoPPU = form.patente;
    this.registroService.addUsuario(this.newUsuario).then(dato =>{ 
      this.newUsuario = <Usuario>{};
      this.showToast('Usuario Creado!');
    });
    this.formularioRegistro.reset();
    this.navController.navigateRoot('inicio');
  }//findel método

 async showToast(msg){
  const toast = await this.toastController.create({ 
    message: msg,
    duration: 2000
  });
  toast.present();
 }







}
