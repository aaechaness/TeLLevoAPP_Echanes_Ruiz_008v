import { Component, OnInit } from '@angular/core';
import { MenuController } from '@ionic/angular';
import { AlertController, NavController } from '@ionic/angular';

@Component({
  selector: 'app-action-sheet',
  templateUrl: './action-sheet.page.html',
  styleUrls: ['./action-sheet.page.scss'],
})
export class ActionSheetPage implements OnInit {

  constructor(
    public alertController: AlertController,
    public navCtrl: NavController) { }

  ngOnInit() {
  }
/* ----------------- SALIR  / LogOut ------------------------------- */
async salir(){
  const alert = await this.alertController.create({
    header: 'Salir',
    message: '¿Realmente Quieres Salir?',
    buttons: [
      {
        text: 'No',
        handler: () => {
          
        }
      }, {
        text: 'Si',
        handler: () => {
          localStorage.removeItem('ingresado');
          this.navCtrl.navigateRoot('login');
        }
      }
    ]
  });

  await alert.present();
}
/* ----------------- SALIR  / LogOut ------------------------------- */

}
