import { Component, OnInit } from '@angular/core';
import { NoticiasService } from 'src/app/services/noticias.service';
import {Article} from '../../interfaces/interfaces';

import { MenuController } from '@ionic/angular';
import { AlertController, NavController } from '@ionic/angular';

@Component({
  selector: 'app-noticias',
  templateUrl: './noticias.page.html',
  styleUrls: ['./noticias.page.scss'],
})
export class NoticiasPage implements OnInit {

  //objeto tipo arreglo de la interfaz Article
  noticias: Article[] = []

  constructor(private noticiasService:NoticiasService,
    public alertController: AlertController,
    public navCtrl: NavController,) { }

  ngOnInit() {
    this.noticiasService.getTopHeadLines().subscribe(resp=>{
      console.log('noticias', resp);
      //push permite añadir al arreglo cada objeto de tipo noticias obtenidas desde el servicio.
      this.noticias.push(...resp.articles);
    });
  }
  /* ----------------- SALIR  / LogOut ------------------------------- */
  async salir(){
    const alert = await this.alertController.create({
      header: 'Salir',
      message: '¿Quieres Salir?',
      buttons: [
        {
          text: 'No',
          handler: () => {
            
          }
        }, {
          text: 'Si',
          handler: () => {
            localStorage.removeItem('ingresado');
            this.navCtrl.navigateRoot('login');
          }
        }
      ]
    });

    await alert.present();
  }
/* ----------------- SALIR  / LogOut ------------------------------- */

}


