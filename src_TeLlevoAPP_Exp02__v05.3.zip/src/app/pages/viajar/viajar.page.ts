import { Component, OnInit, ViewChild } from '@angular/core';
import { ServicedatosService, Datos } from '../../services/servicedatos.service';
import { Platform, ToastController, IonList} from '@ionic/angular';
import { MenuController } from '@ionic/angular';
import { AlertController, NavController } from '@ionic/angular';

@Component({
  selector: 'app-viajar',
  templateUrl: './viajar.page.html',
  styleUrls: ['./viajar.page.scss'],
})
export class ViajarPage implements OnInit {

  datos: Datos[] = [];
  newDato: Datos = <Datos>{};
  @ViewChild('myList')myList :IonList; 
  

  constructor(private menuController: MenuController,
    private storageService: ServicedatosService,
    public alertController: AlertController,
    public navCtrl: NavController,
    private plt: Platform,
    private toastController: ToastController) {
      this.plt.ready().then(()=>{
        this.loadDatos();
      });
    }

  ngOnInit() {
  }

  mostrarMenu()
  {
    this.menuController.open('first');
  }

  //get
  loadDatos(){
    this.storageService.getDatos().then(datos=>{
      this.datos=datos;
    });
  }
  /* ----------------- SALIR  / LogOut ------------------------------- */
  async salir(){
    const alert = await this.alertController.create({
      header: 'Salir',
      message: '¿Quieres Salir?',
      buttons: [
        {
          text: 'No',
          handler: () => {
            
          }
        }, {
          text: 'Si',
          handler: () => {
            localStorage.removeItem('ingresado');
            this.navCtrl.navigateRoot('login');
          }
        }
      ]
    });

    await alert.present();
  }
/* ----------------- SALIR  / LogOut ------------------------------- */

}
