import { Component } from '@angular/core';

interface Componente{
  icon:string;
  name:string;
  redirecTo:string;
}

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  constructor() {}


  componentes : Componente[] = [
    {
      icon: 'home-outline',
      name: 'Inicio',
      redirecTo: '/inicio'
    },

    /*
    {
      icon: 'paw-outline',
      name: 'Action Sheet',
      redirecTo: '/action-sheet'
    },

    {
      icon: 'sunny-outline',
      name: 'Alert',
      redirecTo: '/alert'
    },

    {
      icon: 'card-outline',
      name: 'Card',
      redirecTo: '/card'
    },*/
    
    {
      icon: 'person-circle-outline',
      name: 'Login',
      redirecTo: '/inputs'
    },
    /*
    {
      icon: 'person-circle-outline',
      name: 'Login',
      redirecTo: '/login'
    },*/
    {
      icon: 'person-add-outline',
      name: 'Registrate',
      redirecTo: '/registro'
    }, 
    
    {
      icon: 'qr-code-outline',
      name: 'About',
      redirecTo: '/about'
    }, 
  ];
  



}
