import { Component, OnInit } from '@angular/core';
import { MenuController } from '@ionic/angular';

@Component({
  selector: 'app-registro',
  templateUrl: './registro.page.html',
  styleUrls: ['./registro.page.scss'],
})
export class RegistroPage implements OnInit {

  constructor(private menuController: MenuController) { }

  ngOnInit() {
  }

  mostrarMenu(){
    this.menuController.open('first');
  }

  usuario = {
    registro:'',
    nombre:'',
    Nickname:'',
    email: '',
    password:'',
    Carrera: '',
    Sede: '',
    Tipo: '',
    Modelo: '',
    Patente:''
  }

  onSubmit(){
    console.log('submit');
    console.log(this.usuario);
  }
}
