import { AppPage } from './app.po';

describe('Ejemplos de pruebas', () => {
  let page: AppPage;

  //configuración del testing 
  beforeEach(() => {
    page = new AppPage();
  });

  //testing a unidades de codigo
  it('Prueba 1', () => {
    page.navigateTo();
    expect(page.getTitleText()).toContain('Bienvenido');
  });

  it('Prueba 2', async () => {
   await page.navigateTo();
    expect(await page.getTitleTextH2()).toEqual('TeLlevoAPP');
  });

  it('Prueba 3', async () => {
    await page.navigateTo();
     expect(await page.getTitlePar()).toEqual('Ingenieria');
   });


});